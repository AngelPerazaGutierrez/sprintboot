package com.sistemadepagosibero.sistema_pagos_backend_ibero.enums;

public enum TypePago {

    EFECTIVO, CHEQUE, TRANSFERENCIA, DEPOSITO
    
}
