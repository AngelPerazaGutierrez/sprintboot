package com.sistemadepagosibero.sistema_pagos_backend_ibero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaPagosBackendIberoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaPagosBackendIberoApplication.class, args);
	}

}
