package com.sistemadepagosibero.sistema_pagos_backend_ibero.enums;

public enum PagoStatus {
    CREADO, VALIDADO, RECHAZADO
}
