package com.sistemadepagosibero.sistema_pagos_backend_ibero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaPagosBackendIberoApplicationTests {

	@Test
	void contextLoads() {
	}

}
